% 10. Usando o predicado inv, defina o predicado sim(L) que verifica se uma lista
% é simétrica. Por exemplo, sim([a,r,a,r,a]) resulta em yes.

sim([]).
sim()